# Notas de Geometría Analítica (6886)

Libro digital del curso de Geometría Analítica, Licenciatura en Matemáticas, Universidad de Sonora. Hecho con [Quarto](https://quarto.org) (tipo de proyecto: `book`).

## Trabajar en RStudio

Es el mismo flujo de tus libros anteriores de Quarto:

1. Abre `notas-geometria-analitica.Rproj` en RStudio.
2. Edita los capítulos `.qmd`.
3. **Render** (o `quarto render` en la terminal). El libro queda en `_book/`.
4. Para verlo mientras escribes: `quarto preview`.

No requiere R ni Python para renderizar: todo el contenido actual es markdown, LaTeX y HTML.

## Estructura

```
_quarto.yml                     configuración del libro (capítulos, tema, PDF)
index.qmd                       "Antes de empezar"
01-...qmd a 07-...qmd           un capítulo por unidad del programa
invernadero.qmd                 portada de la sección opcional de Python
invernadero/                    los cuadernos del invernadero
applets/                        figuras interactivas (HTML+JS autocontenido)
imagenes/                       figuras estáticas
referencias.bib                 bibliografía
estilos.scss                    tema visual (paleta del curso)
.github/workflows/publish.yml   publicación automática en GitHub Pages
diapositivas/                   fuentes Beamer de las presentaciones (Overleaf)
```

**Estado:** el capítulo 1 (Sistemas de coordenadas) está completo; los capítulos 2 a 7 tienen el esqueleto con el orden y el enfoque fijados, y se escriben durante el semestre.

## Publicar en GitHub Pages (una sola vez)

1. Crea un repositorio en GitHub (por ejemplo `notas-geometria-analitica`) y sube esta carpeta.
2. En el repositorio: **Settings → Pages → Source: "GitHub Actions"**.
3. Cada `push` a `main` reconstruye y publica el libro automáticamente.
4. Actualiza `repo-url` en `_quarto.yml` con la URL real de tu repositorio.

## El invernadero (celdas ejecutables, pendiente)

Los cuadernos del invernadero muestran el código de Python pero todavía no lo ejecutan en el navegador. Para activarlo, cuando quieras:

```bash
quarto add r-wasm/quarto-live
```

y en `_quarto.yml` descomenta el filtro `live` (está señalado con un comentario). Después, en los archivos de `invernadero/` —y **sólo** en ellos— cambia los bloques ` ```python ` por ` ```{pyodide} `. La regla de la casa: ninguna página del cuerpo del libro carga Python; sólo el invernadero.

## Advertencia sobre Dropbox

Este repositorio debe vivir **fuera** de Dropbox (por eso está en `Documents`). Git guarda su estado en la carpeta `.git` y la sincronización de Dropbox puede corromperla. El respaldo del repositorio es GitHub: cada `push` deja una copia completa del historial.
